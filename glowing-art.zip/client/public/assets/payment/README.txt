Place the official mobile app brand logos here.
Supported filenames (PNG preferred, SVG fallback):
- jazzcash.png / jazzcash.svg
- easypaisa.png / easypaisa.svg
- usdt-trc20.png / usdt-trc20.svg
- bank-transfer.png / bank-transfer.svg
- crypto.png / crypto.svg

Recommended size: ~128x128px or larger; transparent background.
